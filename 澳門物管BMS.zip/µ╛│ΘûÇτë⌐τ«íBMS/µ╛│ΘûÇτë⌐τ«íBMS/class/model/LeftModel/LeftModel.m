//
//  LeftModel.m
//  澳門物管BMS
//
//  Created by geanguo_lucky on 2018/12/30.
//  Copyright © 2018 geanguo_lucky. All rights reserved.
//

#import "LeftModel.h"

@implementation LeftModel

@end
