//
//  LeftModel.h
//  澳門物管BMS
//
//  Created by geanguo_lucky on 2018/12/30.
//  Copyright © 2018 geanguo_lucky. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LeftModel : NSObject
@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *image;
@end

NS_ASSUME_NONNULL_END
