//
//  NoticeDetailViewController.h
//  澳門物管BMS
//
//  Created by geanguo_lucky on 2019/1/7.
//  Copyright © 2019 geanguo_lucky. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface NoticeDetailViewController : BaseViewController
@property (nonatomic,strong) NSString *noticeId;
@end

NS_ASSUME_NONNULL_END
