//
//  LoginViewController.m
//  澳門物管BMS
//
//  Created by geanguo_lucky on 2018/12/13.
//  Copyright © 2018 geanguo_lucky. All rights reserved.
//
#import <MJExtension/MJExtension.h>
#import "LoginViewController.h"
#import "WebAPIHelper.h"
#import "User.h"
@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *accountTextField;
@property (weak, nonatomic) IBOutlet UITextField *psdTextField;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UIButton *forgetBtn;
@property (nonatomic,strong) NSString *token;
@property (weak, nonatomic) IBOutlet UIImageView *headImg;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _headImg.layer.masksToBounds=YES;
    _headImg.layer.cornerRadius=40;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)loginBtnAction:(id)sender {
    if(_accountTextField.text.length ==0){
         [[[UIAlertView alloc]initWithTitle:@"" message:LocalizedString(@"String_tips_input_tel") delegate:nil cancelButtonTitle:LocalizedString(@"String_confirm") otherButtonTitles: nil] show];
    }else if (_psdTextField.text.length ==0){
          [[[UIAlertView alloc]initWithTitle:@"" message:LocalizedString(@"String_tips_input_password") delegate:nil cancelButtonTitle:LocalizedString(@"String_confirm") otherButtonTitles: nil] show];
    }else{
        NSDictionary *dic =[NSDictionary  dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@%@",_accountTextField.text,_psdTextField.text],@"username",@"password"];
        [[WebAPIHelper sharedWebAPIHelper]postUserLogin:dic completion:^(NSDictionary *dic){
            if(dic !=nil){
                User *user=[User shareUser];
                user=[dic objectForKey:@"user"];
              //  User *user=[User objectWithKeyValues:dic];
                _token=[dic objectForKey:@"token"];
                NSUserDefaults *tokenId=[NSUserDefaults standardUserDefaults];
                [tokenId setObject:_token forKey:Token];
                [self.navigationController popViewControllerAnimated:YES];
            }
        }];
        
      //  [self.navigationController popViewControllerAnimated:YES];
    }
    
}
- (IBAction)forgetBtnAction:(id)sender {
    
    
}

@end
