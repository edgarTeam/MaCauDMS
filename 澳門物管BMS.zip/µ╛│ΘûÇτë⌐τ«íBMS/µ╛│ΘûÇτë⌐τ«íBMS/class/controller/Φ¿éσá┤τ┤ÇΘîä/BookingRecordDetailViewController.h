//
//  BookingRecordDetailViewController.h
//  澳門物管BMS
//
//  Created by geanguo_lucky on 2018/12/20.
//  Copyright © 2018 geanguo_lucky. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BookingRecordDetailViewController : UIViewController
@property (nonatomic,strong)NSString *recordId;
//@property (nonatomic,strong)NSString *placeId;
@end

NS_ASSUME_NONNULL_END
