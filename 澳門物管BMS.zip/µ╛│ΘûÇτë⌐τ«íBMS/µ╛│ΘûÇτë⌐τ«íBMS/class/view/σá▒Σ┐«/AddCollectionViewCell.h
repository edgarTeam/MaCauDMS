//
//  AddCollectionViewCell.h
//  澳門物管BMS
//
//  Created by geanguo_lucky on 2019/1/6.
//  Copyright © 2019 geanguo_lucky. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AddCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *addImageVIew;

@end

NS_ASSUME_NONNULL_END
