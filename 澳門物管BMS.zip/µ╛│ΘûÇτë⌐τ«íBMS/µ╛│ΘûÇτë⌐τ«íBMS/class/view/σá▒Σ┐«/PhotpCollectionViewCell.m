//
//  PhotpCollectionViewCell.m
//  澳門物管BMS
//
//  Created by geanguo_lucky on 2019/1/6.
//  Copyright © 2019 geanguo_lucky. All rights reserved.
//

#import "PhotpCollectionViewCell.h"

@implementation PhotpCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (IBAction)deleteBtnAction:(UIButton *)sender {
}

@end
