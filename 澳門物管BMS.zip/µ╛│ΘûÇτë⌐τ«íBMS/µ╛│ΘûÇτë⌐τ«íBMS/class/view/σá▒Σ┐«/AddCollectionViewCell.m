//
//  AddCollectionViewCell.m
//  澳門物管BMS
//
//  Created by geanguo_lucky on 2019/1/6.
//  Copyright © 2019 geanguo_lucky. All rights reserved.
//

#import "AddCollectionViewCell.h"

@implementation AddCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self.addImageVIew setImage:[UIImage imageNamed:@"add"]];
}

@end
