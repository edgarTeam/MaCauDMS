//
//  GradientView.h
//  练习
//
//  Created by sc-057 on 2018/9/4.
//  Copyright © 2018年 sc-057. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GradientView : UIView

@end
